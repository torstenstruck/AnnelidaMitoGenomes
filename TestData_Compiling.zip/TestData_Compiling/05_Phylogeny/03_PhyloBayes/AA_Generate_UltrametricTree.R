#set working directory to the folder with the inout files
#the following files are needed:
#PB_AA_chain1.con.rooted.tre

library(ape)

#load rooted tree in newick format
mytree <- read.tree("PB_AA_chain1.con.rooted.tre")

#generate time-calibrated ultrametric tree using the correlated method, lambda of 1 and relative dates from 1 to 0
mytimetree <- chronos(mytree, lambda = 1, model = "correlated", control = chronos.control())
plot(mytimetree)
write.tree(mytimetree, file = "PB_AA_chain1.con.rooted.Ultrametric.treefile", append = FALSE,
           digits = 10, tree.names = FALSE)
